<?php
// cron配置文件
// 格式 return array(
// '计划名称'=>array('计划执行的文件名(不含.php)',间隔执行时间(s),第一次执行时间(UNIX时间戳)),...
// );

return array(
   'cronname'=>array('demo','60','1356611601'),
 );