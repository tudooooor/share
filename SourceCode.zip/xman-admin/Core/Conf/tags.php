<?php
//行为配置文件

return array(
	'app_begin' => array('CheckLang'), //语言检测
	//'app_begin' => array('CronRun'),	//定时任务
);